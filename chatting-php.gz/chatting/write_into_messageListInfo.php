<?php
	//增添数据
	function add($sql){
		$mysqli = new mysqli("123.206.17.117","root","yuan3366","chatting");
		//mysqli_set_charset($mysqli,'utf-8');//设置编码格式
		if($mysqli->errno){
			//echo $mysqli->error;	
		}else{
			//echo "connect success!";
		}
		 $res = $mysqli->query($sql);
		 if($res){
			 return true;
		 }else{
			 return false;
		 }
      mysqli_close($mysqli);
	}
	
	if(isset($_POST['ip'])){
        $ip = $_POST['ip'];
        $friend_ip = $_POST['friend_ip'];  
        $netname = $_POST['netname'];
        $touxiang = $_POST['touxiang_id'];
        $state = $_POST['state'];
        $geqian = $_POST['geqian'];
      
		$sql = "INSERT INTO `chatting`.`message_list_info` (`my_ip`, `friend_ip`, `netname`, `touxiang_id`, `state`, `geqian`) VALUES ('$ip', '$friend_ip', '$netname', '$touxiang', '$state', '$geqian')";
		$res = add($sql);

        $response = array();
		if($res){
    		$response["success"] = 0;

		} else{
   		   $response["success"] = 1;
		}
		  print(json_encode($response));
 	}

?>

