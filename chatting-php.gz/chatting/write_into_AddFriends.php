<?php
	//增添数据
	function add($sql){
		$mysqli = new mysqli("123.206.17.117","root","yuan3366","chatting");
		//mysqli_set_charset($mysqli,'utf-8');//设置编码格式
		if($mysqli->errno){
			//echo $mysqli->error;	
		}else{
			//echo "connect success!";
		}
		 $res = $mysqli->query($sql);
		 if($res){
			 return true;
		 }else{
			 return false;
		 }
      mysqli_close($mysqli);
	}
	
	if(isset($_POST['ip'])){
        $ip = $_POST['ip'];
        $friend_ip = $_POST['friend_ip'];
        //$group = $_POST['group'];
        $sql = "INSERT INTO my_all_friends_info (my_ip_address,friend_ip,my_all_friends_info.`group`) VALUES ('$ip','$friend_ip','我的好友')";
       	//$sql2 = "INSERT INTO personal_info (ip_address,touxiang_num) values('$username',2130837597)";
		$res = add($sql);
      	//$res2 = add($sql2);
        $response = array();
		if($res){
    		$response["success"] = 0;

		} else{
   		   $response["success"] = 1;
		}
		  print(json_encode($response));
	
 	}

?>

