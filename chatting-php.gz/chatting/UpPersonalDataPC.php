<?php
	//增添数据
	function add($sql){
		$mysqli = new mysqli("123.206.17.117","root","yuan3366","chatting");
		//mysqli_set_charset($mysqli,'utf-8');//设置编码格式
		if($mysqli->errno){
			//echo $mysqli->error;	
		}else{
			//echo "connect success!";
		}
		 $res = $mysqli->query($sql);
		 if($res){
			 return true;
		 }else{
			 return false;
		 }
      mysqli_close($mysqli);
	}
	
	
	//获取客户端发来的请求信息  
	//netname geqian_data home_data school_data class_data ip_address
	//if(isset($_POST['netname'])){
		$ip_address2 = $_POST['ip_address'];
        $netname1 = $_POST['netname'];
      	$geqian_data1 = $_POST['geqian_data'];
        $home_data1 = $_POST['home_data'];
   	    $school_data1 = $_POST['school_data'];
        $class_data1 = $_POST['class_data'];
        $ip_address1 = $_POST['ip_address'];
		$sex = $_POST['sex_data'];
      	$phone_num1 = $_POST['phone_data'];
      	$email_data = $_POST['email_data'];
      	$birthday1 = $_POST['birthday_data'];

      
      
		$sql = "update personal_info set netname = '$netname1',geqian_data = '$geqian_data1',home_data = '$home_data1',school_data = '$school_data1',class_data = '$class_data1',
        		sex = '$sex',phone_num = '$phone_num1',email = '$email_data',birthday = '$birthday1' where ip_address = '$ip_address2'";
		$res = add($sql);
		if($res){
			echo 'add personal_data success';
           $arr = array ('a'=>1);
		}else{
			echo 'add personal_data failed';
           $arr = array ('a'=>0);
		}
	    echo json_encode($arr);//以json的形式返回给客户端   {"a":1}
    //  }
?>
