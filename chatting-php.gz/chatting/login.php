<?php

error_reporting(E_ALL ^ E_NOTICE);

$con = mysqli_connect("123.206.17.117","root","yuan3366","chatting");

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "select * 
from user_info 
where username='$username' and password=md5('$password')";


//如果在 where 子句中使用参数，也会导致全表扫描。因为SQL只有在运行时才会解析局部变量，但优化程序不能将访问计划的选择推迟到运行时；
//它必须在编译时进行选择。然而，如果在编译时建立访问计划，变量的值还是未知的，因而无法作为索引选择的输入项。如下面语句将进行全表扫描：
//select id from t where num=@num
//可以改为强制查询使用索引：
//select id from t with(index(索引名)) where num=@num 

$result=mysqli_query($con,$sql);

$num = mysqli_num_rows($result);

$response = array();

if($num > 0){
    $response["success"] = 1;

}else{
    $response["success"] = 0;
}

echo json_encode($response);
//以json的形式返回给客户端

mysqli_close($con);