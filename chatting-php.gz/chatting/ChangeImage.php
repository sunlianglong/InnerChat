<?php
	//增添数据
	function add($sql){
		$mysqli = new mysqli("123.206.17.117","root","yuan3366","chatting");
		//mysqli_set_charset($mysqli,'utf-8');//设置编码格式
		if($mysqli->errno){
			//echo $mysqli->error;	
		}else{
			//echo "connect success!";
		}
		 $res = $mysqli->query($sql);
		 if($res){
			 return true;
		 }else{
			 return false;
		 }
      mysqli_close($mysqli);
	}
	
	
	//获取客户端发来的请求信息  
	//netname geqian_data home_data school_data class_data ip_address

        $ip_address1 = $_POST['ip'];
		$touxiang_num1=$_POST['image'];
        $sql = "UPDATE personal_info SET touxiang_num = '$touxiang_num1' WHERE ip_address = '$ip_address1'"; 
		$res = add($sql);
		if($res){
			echo 'add personal_data success';
           $arr = array ('a'=>1);
		}else{
			echo 'add personal_data failed';
           $arr = array ('a'=>0);
		}
	    echo json_encode($arr);//以json的形式返回给客户端   {"a":1}
      
?>
