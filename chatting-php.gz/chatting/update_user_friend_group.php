<?php
	//增添数据
	function add($sql){
		$mysqli = new mysqli("123.206.17.117","root","yuan3366","chatting");
		//mysqli_set_charset($mysqli,'utf-8');//设置编码格式
		if($mysqli->errno){
			//echo $mysqli->error;	
		}else{
			//echo "connect success!";
		}
		 $res = $mysqli->query($sql);
		 if($res){
			 return true;
		 }else{
			 return false;
		 }
      mysqli_close($mysqli);
	}
	
	
	//获取客户端发来的请求信息  
	//netname geqian_data home_data school_data class_data ip_address
	//if(isset($_POST['netname'])){
		$search = $_POST['search'];
		$friend = $_POST['friend'];
		$group = $_POST['group'];
		$beizhu = $_POST['beizhu'];

		$sql = "update my_all_friends_info set my_all_friends_info.group = '$group',beizhu='$beizhu' where my_ip_address = '$search' AND friend_ip='$friend'";
		$res = add($sql);
		if($res){
			echo 'update friend success';
           $arr = array ('a'=>1);
		}else{
			echo 'update frienda failed';
           $arr = array ('a'=>0);
		}
	    echo json_encode($arr);//以json的形式返回给客户端   {"a":1}
    //  }
?>
