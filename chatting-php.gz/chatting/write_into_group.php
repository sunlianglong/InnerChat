<?php
	//增添数据
	function add($sql){
		$mysqli = new mysqli("123.206.17.117","root","yuan3366","chatting");
		//mysqli_set_charset($mysqli,'utf-8');//设置编码格式
		if($mysqli->errno){
			//echo $mysqli->error;	
		}else{
			//echo "connect success!";
		}
		 $res = $mysqli->query($sql);
		 if($res){
			 return true;
		 }else{
			 return false;
		 }
      mysqli_close($mysqli);
	}
	
	//if(isset($_POST['ip'])){
        $my_ipaddress = $_POST['my_ipaddress'];
        $goup_name = $_POST['goup_name'];

        $sql = "INSERT INTO my_group_info (my_ipaddress,my_group_info.`goup_name`,friends_number) VALUES ('$my_ipaddress','$goup_name',0)";
		$res = add($sql);
        $response = array();
		if($res){
    		$response["success"] = 0;

		} else{
   		   $response["success"] = 1;
		}
		  print(json_encode($response));
	
 	//}

?>

