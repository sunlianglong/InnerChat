<?php  
error_reporting(E_ALL ^ E_NOTICE);

$con = mysqli_connect("123.206.17.117","root","yuan3366","chatting");


// 修改数据库连接字符集为 utf8
mysqli_set_charset($con,"utf-8");

    //获取客户端发来的请求信息  
    $search = $_POST['search'];  
	$goup_name=$_POST['goup_name'];
      

$sql = "select goup_name,friends_number
from my_group_info
where my_ipaddress='$search' AND goup_name='$goup_name'";

$result=mysqli_query($con,$sql);

$num = mysqli_num_rows($result);//结果集的总行数

$response = array();//定义一个数组response

while($row=mysqli_fetch_assoc($result))
$output[]=$row;
print(json_encode($output));

//以json的形式返回给客户端
mysqli_close($con);

?>  