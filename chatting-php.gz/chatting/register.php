<?php
	//增添数据
	function add($sql){
		$mysqli = new mysqli("123.206.17.117","root","yuan3366","chatting");
		//mysqli_set_charset($mysqli,'utf-8');//设置编码格式
		if($mysqli->errno){
			//echo $mysqli->error;	
		}else{
			//echo "connect success!";
		}
		 $res = $mysqli->query($sql);
		 if($res){
			 return true;
		 }else{
			 return false;
		 }
      mysqli_close($mysqli);
	}
	
	if(isset($_POST['name'])){
        $username = $_POST['name'];
        $password = $_POST['password'];
        $sql = "INSERT INTO user_info (username,password) VALUES ('$username',md5('$password'))";
       	$sql2 = "INSERT INTO personal_info (ip_address,touxiang_num) values('$username',2130837597)";
        $sql3 = "INSERT INTO my_all_friends_info (my_ip_address) VALUES ('$username')";
		$res = add($sql);
      	$res2 = add($sql2);
      	$res3 = add($sql3);
        $response = array();

		if($res){
    		$response["success"] = 0;

		} else{
   		   $response["success"] = 1;
		}
		  print(json_encode($response));
	
 	}

?>

